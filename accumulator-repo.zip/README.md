# Accumulator

A single-file parlay/accumulator builder for sports betting. Live odds via [The Odds API](https://the-odds-api.com), with a same-game-parlay correlation engine, alt-line modeling, and bankroll-style slip management.

[**→ Open the live page**](#) <!-- replace with your Pages URL after deploying, e.g. https://yourname.github.io/accumulator/ -->

## Features

- **Live odds** for NBA, WNBA, MLB, NFL, NHL — moneylines, spreads, totals, and player props
- **Alt-line model** — calibrated Student's t(5) extrapolation matches industry sportsbook pricing across the entire range, with self-consistent fitting against API observations
- **Same-game parlay engine** — 178-rule correlation matrix covering player stacks, game-script tailwinds, mutual exclusions; deep-research-tuned against Wizard of Odds, OddsIndex, and DFS empirical data
- **Six independent slip slots** — build and compare multiple parlays side-by-side
- **Tracker** with SGP and Intervened tags + filters
- **Margin controls** — global or per-market hold percentage, custom or American odds spec
- **No backend, no build step** — single 341 KB HTML file, runs entirely in your browser

## Setup

1. Get a free API key from [the-odds-api.com](https://the-odds-api.com) (no credit card; 500 credits/month free tier).
2. Open the page.
3. Paste your key when prompted. It's stored locally in your browser — never sent anywhere except to the Odds API.

## Running locally

It's a single file. Either:

```bash
# Open it directly
open index.html

# Or serve it (any static server works)
python3 -m http.server 8000
# → http://localhost:8000
```

## Deploying to GitHub Pages

1. Push this repo to GitHub.
2. **Settings** → **Pages** → Source: **Deploy from a branch** → Branch: `main` (or `master`), folder: `/ (root)`.
3. Save. The site goes live at `https://<username>.github.io/<repo>/` within a minute or two.

## How the alt-line model works

Player-prop and game-line markets typically only quote one or two main lines. The app extrapolates to virtual alts (e.g. NBA points at every 0.5 step from line−3 to line+5) using:

- **Poisson** for low-mean integer counting stats (steals, blocks, home runs, etc.)
- **Student's t-5** for higher-mean continuous-ish stats (points, yards, totals, spreads)

The t-5 distribution has 1/z⁵ tail decay — fatter than Normal (which would price 55+ pt alts at +75,000) but much thinner than Cauchy (which would price them at +1,300, way too generous to bettor). It calibrates to actual book pricing within ±10% across the full z range from 0 to 5.

When the API gives us 2+ alt lines, μ and σ are fitted from the observations against the same t-5 CDF used for extrapolation (self-consistent — no calibration/extrapolation mismatch).

## How the SGP correlation engine works

Each parlay leg is matched against a 178-rule correlation matrix yielding a pairwise ρ. The combined parlay probability is then computed via Gaussian-copula shrinkage:

```
P(A ∩ B) = P(A)·P(B) + ρ·√(P(A)(1−P(A))·P(B)(1−P(B)))
```

For 3+ legs, pairwise ρ values feed a Cholesky-decomposed Monte Carlo simulation (50k draws, normal copula). Results display as the parlay's combined American odds vs. naive-multiplication.

Rule examples:
- NFL QB pass yds + same-team WR rec yds: ρ = 0.45 (DFS-empirical 0.46–0.54)
- NBA same-game total over + player Pts under: ρ = −0.25
- MLB total under + Pitcher Ks over: ρ = +0.30 (ace dominating)
- ML home + spread away same game: ρ = −0.85 (mirror-game-state)

When player-prop legs lack team metadata (which the Odds API doesn't expose), the engine falls back to same-game rules with attenuated ρ (~65–75% of the same-team value) rather than dropping the correlation entirely.

## License

MIT — do whatever you want.

## Disclaimer

This is a tool for analyzing posted odds and constructing parlays. It does not place bets, take wagers, or move money. Bet at your own risk. The alt-line model is calibrated to match retail sportsbook pricing — it is not a +EV signal. Sports betting can be addictive; if you or someone you know has a problem, the [National Council on Problem Gambling helpline](https://www.ncpgambling.org/help-treatment/national-helpline-1-800-522-4700/) is 1-800-GAMBLER.
